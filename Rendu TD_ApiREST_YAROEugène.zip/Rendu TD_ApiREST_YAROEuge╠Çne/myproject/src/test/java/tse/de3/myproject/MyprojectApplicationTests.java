package tse.de3.myproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
