package com.example.euyarotse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EuyaroTseApplication {

	public static void main(String[] args) {
		SpringApplication.run(EuyaroTseApplication.class, args);
	}

}
