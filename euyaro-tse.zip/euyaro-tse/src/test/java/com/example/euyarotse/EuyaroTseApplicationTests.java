package com.example.euyarotse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EuyaroTseApplicationTests {

	@Test
	void contextLoads() {
	}

}
