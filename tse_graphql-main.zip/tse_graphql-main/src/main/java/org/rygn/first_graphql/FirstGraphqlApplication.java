package org.rygn.first_graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstGraphqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstGraphqlApplication.class, args);
	}

}
