package org.rygn.tse_spring.interfaces;

public interface Canine {

}
