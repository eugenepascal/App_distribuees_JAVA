package org.rygn.tse_spring.components;

import org.rygn.tse_spring.interfaces.Bird;

public class Owl implements Bird {

	@Override
	public String toString() {
		return "Owl instance";
	}
}
